from .init import db

class Admin(db.Model):
    __tablename__ = 'admins'

    id = db.Column(db.Integer, primary_key=True)

    user_id = db.Column(
        db.Integer,
        db.ForeignKey('users.id'),
        nullable=False,
        unique=True
    )

    full_name_ad = db.Column(db.String(100), nullable=False)

    level = db.Column(db.Integer, default=1)
    note = db.Column(db.Text)

    user = db.relationship('User', backref=db.backref('admin', uselist=False))

    def __repr__(self):
        return f"<Admin {self.full_name} (level {self.level})>"
