from .init import db

class Enrollment(db.Model):
    __tablename__ = 'enrollments'

    id = db.Column(db.Integer, primary_key=True)

    student_id = db.Column(
        db.Integer,
        db.ForeignKey('students.id'),
        nullable=False
    )

    course_id = db.Column(
        db.Integer,
        db.ForeignKey('courses.id'),
        nullable=False
    )

    status = db.Column(db.String(20), default='pending')
    # pending | approved | rejected

    created_at = db.Column(db.DateTime, server_default=db.func.now())

    student = db.relationship('Student', backref='enrollments')
    course = db.relationship('Course', backref='enrollments')
