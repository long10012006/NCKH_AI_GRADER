from .init import db

class Teacher(db.Model):
    __tablename__ = 'teachers'

    id = db.Column(db.Integer, primary_key=True)

    user_id = db.Column(
        db.Integer,
        db.ForeignKey('users.id'),
        nullable=False,
        unique=True
    )

    # Thông tin cá nhân
    full_nametc = db.Column(db.String(100), nullable=False)
    date_of_birth_tc = db.Column(db.Date)
    gender = db.Column(db.String(10))
    address_tc = db.Column(db.String(255))

    # Thông tin chuyên môn
    teacher_code = db.Column(db.String(20), unique=True, nullable=False)
    department = db.Column(db.String(100))
    degree = db.Column(db.String(50))   # ThS, TS, PGS...
    specialization = db.Column(db.String(100))

    user = db.relationship('User', backref=db.backref('teacher', uselist=False))

    def __repr__(self):
        return f"<Teacher {self.teacher_code} - {self.full_nametc}>"
