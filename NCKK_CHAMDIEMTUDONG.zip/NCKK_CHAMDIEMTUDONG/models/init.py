from flask_sqlalchemy import SQLAlchemy # type: ignore

db = SQLAlchemy()


from .student_md import Student
from .teacher_md import Teacher
from .admin_md import Admin
from .course_md import Course
from .enrollment_md import Enrollment

