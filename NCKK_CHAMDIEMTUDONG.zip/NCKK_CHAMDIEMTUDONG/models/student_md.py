from .init import db

class Student(db.Model):
    __tablename__ = 'students'

    id = db.Column(db.Integer, primary_key=True)

    user_id = db.Column(
        db.Integer,
        db.ForeignKey('users.id'),
        nullable=False,
        unique=True
    )

    # Thông tin cá nhân
    full_name = db.Column(db.String(100), nullable=False)
    date_of_birth = db.Column(db.Date)
    gender = db.Column(db.String(10))
    address = db.Column(db.String(255))

    # Thông tin học tập
    student_code = db.Column(db.String(20), unique=True, nullable=False)  # Mã sinh viên
    major = db.Column(db.String(100)) # Ngành học
    class_name = db.Column(db.String(50)) # Lớp học
    enrollment_year = db.Column(db.Integer) # Năm nhập học

    gpa = db.Column(db.Float, default=0.0) # Điểm trung bình tích lũy
    status = db.Column(db.String(20), default='studying')
    # studying | suspended | graduated

    user = db.relationship('User', backref=db.backref('student', uselist=False))

    def __repr__(self):
        return f"<Student {self.student_code} - {self.full_name}>"
