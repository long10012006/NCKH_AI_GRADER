from .init import db

class Course(db.Model):
    __tablename__ = 'courses'

    id = db.Column(db.Integer, primary_key=True)

    name = db.Column(db.String(100), nullable=False)
    description = db.Column(db.Text)

    teacher_id = db.Column(
        db.Integer,
        db.ForeignKey('teachers.id'),
        nullable=False
    )

    created_at = db.Column(db.DateTime, server_default=db.func.now())

    teacher = db.relationship('Teacher', backref='courses')

    def __repr__(self):
        return f"<Course {self.name}>"
