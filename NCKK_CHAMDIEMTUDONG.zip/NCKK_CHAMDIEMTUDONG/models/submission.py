
from models.init import db
from datetime import datetime

class Submission(db.Model):
    __tablename__ = 'submissions'

    id = db.Column(db.Integer, primary_key=True)

    student_id = db.Column(
        
        db.Integer,
        db.ForeignKey('students.id'),
        nullable=False
    )
    student = db.relationship('Student', backref='submissions')


    title = db.Column(db.String(255), nullable=False)
    subject = db.Column(db.String(255))
    note = db.Column(db.Text)

    file_path = db.Column(db.String(255), nullable=False)

    timestamp = db.Column(db.DateTime, default=datetime.utcnow)

    status = db.Column(db.String(50), default='Đã nộp')
    score = db.Column(db.Float, nullable=True)  # giảng viên chấm sau
