from werkzeug.security import generate_password_hash # type: ignore
from models.users import User, RoleEnum
from models.admin_md import Admin
from models.init import db

def create_default_admin():
    admin_user = User.query.filter_by(role=RoleEnum.admin.value).first()
    if admin_user:
        return

    user = User(
        username='admin',
        email='admin123@gmail.com',
        password=generate_password_hash('admin123'),
        role=RoleEnum.admin.value
    )

    db.session.add(user)
    db.session.flush()

    admin = Admin(
        user_id=user.id,
        full_name_ad='Administrator',
        level=10,
        note='Default admin account'
    )

    db.session.add(admin)
    db.session.commit()
