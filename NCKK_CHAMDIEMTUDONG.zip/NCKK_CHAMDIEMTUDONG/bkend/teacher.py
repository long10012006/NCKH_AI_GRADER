from flask import Blueprint, render_template, request, redirect, url_for, flash, session  # type: ignore
from models.submission import Submission
from models.teacher_md import Teacher
from models.users import RoleEnum
from models.init import db
from models.course_md import Course
from models.enrollment_md import Enrollment



teacher_bp = Blueprint('teacher', __name__)
@teacher_bp.route('/teacher')
def dashboard():
    if session.get('role') != RoleEnum.teacher.value:
        flash("Bạn không có quyền truy cập trang này.", "danger")
        return redirect(url_for('auth.login'))
    user_id = session.get('user_id')
    return render_template('home_teacher.html',teacher = Teacher.query.filter_by(user_id=user_id).first())

@teacher_bp.route('/teacher/submissions')
def submissions_list():
    if session.get('role') != RoleEnum.teacher.value:
        flash("Bạn không có quyền truy cập trang này.", "danger")
        return redirect(url_for('auth.login'))

    submissions = Submission.query.order_by(Submission.timestamp.desc()).all()
    teacher = Teacher.query.filter_by(user_id=session.get('user_id')).first()

    return render_template(
        'teacher_submission.html',
        submissions=submissions,teacher=teacher
    )


@teacher_bp.route('/teacher/submission/<int:id>')
def submission_detail(id):
    if session.get('role') != RoleEnum.teacher.value:
        flash("Bạn không có quyền truy cập trang này.", "danger")
        return redirect(url_for('auth.login'))

    submission = Submission.query.get_or_404(id)

    return render_template(
        'teacher_submission_detail.html',
        submission=submission,teacher=Teacher.query.filter_by(user_id=session.get('user_id')).first()
    )

# LỚP HỌC :
@teacher_bp.route('/teacher/courses')
def teacher_courses():
    if session.get('role') != RoleEnum.teacher.value:
        return redirect(url_for('auth.login'))

    user_id = session.get('user_id')
    teacher = Teacher.query.filter_by(user_id=user_id).first()

    courses = Course.query.filter_by(teacher_id=teacher.id).all()
    for c in courses:
        c.pending_count = Enrollment.query.filter_by(
        course_id=c.id,
        status='pending'
    ).count()


    return render_template(
        'teacher_courses.html',
        courses=courses,
        teacher=teacher
    )

@teacher_bp.route('/teacher/create-course', methods=['POST'])
def create_course():
    if session.get('role') != RoleEnum.teacher.value:
        return redirect(url_for('auth.login'))

    user_id = session.get('user_id')
    teacher = Teacher.query.filter_by(user_id=user_id).first()

    name = request.form.get('name')
    description = request.form.get('description')

    course = Course(
        name=name,
        description=description,
        teacher_id=teacher.id
    )

    db.session.add(course)
    db.session.commit()

    return redirect(url_for('teacher.teacher_courses'))

@teacher_bp.route('/teacher/approve/<int:enroll_id>')
def approve_student(enroll_id):
    enrollment = Enrollment.query.get_or_404(enroll_id)
    enrollment.status = 'approved'
    db.session.commit()
    return redirect(request.referrer)


@teacher_bp.route('/teacher/reject/<int:enroll_id>')
def reject_student(enroll_id):
    enrollment = Enrollment.query.get_or_404(enroll_id)
    enrollment.status = 'rejected'
    db.session.commit()
    return redirect(request.referrer)
#xem chi tiết lớp
@teacher_bp.route('/course/<int:course_id>')
def view_course(course_id):
    course = Course.query.get_or_404(course_id)

    approved = Enrollment.query.filter_by(
        course_id=course_id,
        status='approved'
    ).all()

    pending = Enrollment.query.filter_by(
        course_id=course_id,
        status='pending'
    ).all()

    return render_template(
        "teacher_view_course.html",
        course=course,
        approved=approved,
        pending=pending
    )
