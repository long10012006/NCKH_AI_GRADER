from flask import Blueprint, render_template, redirect, url_for, flash, session # type: ignore
from models.users import RoleEnum
from models.admin_md import Admin

admin_bp = Blueprint('admin', __name__)

@admin_bp.route('/')
def dashboard():
    if session.get('role') != RoleEnum.admin.value:
        flash("Bạn không có quyền truy cập trang này.", "danger")
        return redirect(url_for('auth.login'))

    user_id = session.get('user_id')
    admin = Admin.query.filter_by(user_id=user_id).first()

    if not admin:
        flash("Admin chưa được khởi tạo", "danger")
        return redirect(url_for('auth.logout'))

    return render_template('home_admin.html', admin=admin)
