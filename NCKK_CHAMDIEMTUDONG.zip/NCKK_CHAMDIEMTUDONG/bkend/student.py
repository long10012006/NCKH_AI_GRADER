from flask import Blueprint, render_template, request, redirect, url_for, flash, session  # type: ignore
from models.student_md import Student
from models.users import RoleEnum
from models.init import db
from datetime import datetime
import os
from models.submission import Submission
from models.course_md import Course
from models.enrollment_md import Enrollment

student_bp = Blueprint('student', __name__)
#đăng ký 
@student_bp.route('/student')
def dashboard():
    if session.get('role') != RoleEnum.student.value:
        flash("Bạn không có quyền truy cập trang này.", "danger")
        return redirect(url_for('auth.login'))
    user_id = session.get('user_id')
    return render_template('home_students.html', student = Student.query.filter_by(user_id=user_id).first())


# chuyển tab qua các trang sv
@student_bp.route('/thong_tin_sv')
def thong_tin_ca_nhan():
    if session.get('role') != RoleEnum.student.value:
        flash("Bạn không có quyền truy cập trang này.", "danger")
        return redirect(url_for('auth.login'))
    user_id = session.get('user_id')
    return render_template('thong_tin_ca_nhan.html', student = Student.query.filter_by(user_id=user_id).first())


@student_bp.route('/submit_sv', methods=['GET', 'POST'])
def submit_student():
    if session.get('role') != RoleEnum.student.value:
        flash("Bạn không có quyền truy cập trang này.", "danger")
        return redirect(url_for('auth.login'))
    user_id = session.get('user_id')
    student = Student.query.filter_by(user_id=user_id).first()

    if request.method == 'POST':
        title = request.form.get('title')
        subject = request.form.get('subject')
        note = request.form.get('note')
        file = request.files.get('file')

        if not file:
            flash("Chưa chọn file")
            return redirect(request.url)

        upload_folder = 'static/uploads'
        os.makedirs(upload_folder, exist_ok=True)

        filename = f"{datetime.now().timestamp()}_{file.filename}"
        file_path = os.path.join(upload_folder, filename)
        file.save(file_path)

        submission = Submission(
            student_id=student.id,
            title=title,
            subject=subject,
            note=note,
            file_path=file_path
        )

        db.session.add(submission)
        db.session.commit()

        # 👉 CHƯA CÓ TEACHER → TẠM CHƯA GHI DB
        # Sau này chỉ cần tạo bảng submissions rồi insert lại

        flash("Nộp bài thành công!")
        return redirect(url_for('student.submit_student'))

    return render_template('submit_student.html', student=student)

@student_bp.route('/history')
def history():
    if session.get('role') != RoleEnum.student.value:
        flash("Bạn không có quyền truy cập trang này.", "danger")
        return redirect(url_for('auth.login'))
    user_id = session.get('user_id')
    student = Student.query.filter_by(user_id=user_id).first()
    submissions = Submission.query.filter_by(student_id=student.id).order_by(Submission.timestamp.desc()).all()
    return render_template('history_submit_student.html', student=student, submissions=submissions)

#edit sửa đổi 
@student_bp.route('/student/edit-profile', methods=['GET', 'POST'])
def edit_profile():
    user_id = session.get('user_id')
    if not user_id:
        return redirect(url_for('auth.login'))

    student = Student.query.filter_by(user_id=user_id).first()

    if request.method == 'POST':
        student.full_name = request.form.get('full_name')
        student.gender = request.form.get('gender')

        dob_str = request.form.get('date_of_birth')
        if dob_str:
            student.date_of_birth = datetime.strptime(dob_str, "%Y-%m-%d").date()

        student.address = request.form.get('address')

        db.session.commit()
        return redirect(url_for('student.thong_tin_ca_nhan'))

    return render_template('edit_profile.html', student=student)

# LỚP HỌC:
@student_bp.route('/student/courses')
def student_courses():
    if session.get('role') != RoleEnum.student.value:
        return redirect(url_for('auth.login'))

    user_id = session.get('user_id')
    student = Student.query.filter_by(user_id=user_id).first()

    all_courses = Course.query.all()

    enrollments = Enrollment.query.filter_by(student_id=student.id).all()

    return render_template(
        'student_courses.html',
        student=student,
        courses=all_courses,
        enrollments=enrollments
    )

@student_bp.route('/student/join/<int:course_id>')# đăng ký vào lớp học
def join_course(course_id):
    if session.get('role') != RoleEnum.student.value:
        return redirect(url_for('auth.login'))

    user_id = session.get('user_id')
    student = Student.query.filter_by(user_id=user_id).first()

    exists = Enrollment.query.filter_by(
        student_id=student.id,
        course_id=course_id
    ).first()

    if not exists:
        enrollment = Enrollment(
            student_id=student.id,
            course_id=course_id
        )
        db.session.add(enrollment)
        db.session.commit()

    return redirect(url_for('student.student_courses'))


