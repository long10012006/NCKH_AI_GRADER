from flask import Blueprint, render_template, request, redirect, url_for, flash, session # type: ignore
from werkzeug.security import generate_password_hash , check_password_hash # type: ignore
from models.init import db
from models.users import User, RoleEnum
from models.student_md import Student
from models.teacher_md import Teacher
from datetime import datetime


auth_bp = Blueprint('auth', __name__)

@auth_bp.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        try:
            username = request.form.get('username', '').strip()
            email = request.form.get('email', '').strip()
            password = request.form.get('password', '')
            phone = request.form.get('phone', '').strip()
            role = request.form.get('role')

            # ===== kiểm tra trùng =====
            exists = User.query.filter(
                (User.username == username) | (User.email == email)
            ).first()
            if exists:
                flash("Tài khoản hoặc email đã tồn tại", "danger")
                return render_template('register.html')

            # ===== parse date_of_birth =====
            dob_raw = request.form.get('date_of_birth')
            date_of_birth = None
            if dob_raw:
                date_of_birth = datetime.strptime(dob_raw, "%Y-%m-%d").date()

            # ===== tạo user =====
            user = User(
                username=username,
                email=email,
                phone=phone,
                password=generate_password_hash(password),
                role=role
            )

            db.session.add(user)
            db.session.flush()  # lấy user.id

            # ===== STUDENT =====
            if user.role == RoleEnum.student.value:
                student = Student(
                    user_id=user.id,
                    full_name=request.form.get('full_name'),
                    date_of_birth=date_of_birth,   #     DATE OBJECT
                    gender=request.form.get('gender'),
                    address=request.form.get('address'),
                    student_code=request.form.get('student_code'),
                    major=request.form.get('major'),
                    class_name=request.form.get('class_name'),
                    enrollment_year=int(request.form.get('enrollment_year'))
                )
                db.session.add(student)

            # ===== TEACHER =====
            elif user.role == RoleEnum.teacher.value:
                teacher = Teacher(
                    user_id=user.id,
                    full_nametc=request.form.get('full_name'),
                    date_of_birth_tc=date_of_birth,   
                    gender=request.form.get('gender'),
                    address_tc=request.form.get('address'),
                    teacher_code=request.form.get('teacher_code'),
                    department=request.form.get('department'),
                    degree=request.form.get('degree'),
                    specialization=request.form.get('specialization')
                )
                db.session.add(teacher)

            db.session.commit()

            flash("Đăng ký thành công, hãy đăng nhập", "success")
            return redirect(url_for('auth.login'))

        except Exception as e:
            db.session.rollback()
            print(" REGISTER ERROR:", e)
            flash("Có lỗi xảy ra khi đăng ký", "danger")
            return render_template('register.html')

    return render_template('register.html')


@auth_bp.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form.get('username', '').strip()
        password = request.form.get('password', '')

        user = User.query.filter_by(username=username).first()

        if not user or not check_password_hash(user.password, password): 
            flash("Sai tài khoản hoặc mật khẩu", "danger")
            return render_template('login.html')

        # lưu session
        session['user_id'] = user.id
        session['role'] = user.role 

        # phân quyền
        if user.role == RoleEnum.admin.value:
            return redirect(url_for('admin.dashboard'))
        elif user.role == RoleEnum.teacher.value:
            return redirect(url_for('teacher.dashboard'))
        else:
            return redirect(url_for('student.dashboard'))

    return render_template('login.html')

@auth_bp.route('/logout')
def logout():
    session.clear()
    flash("Đã đăng xuất", "success")
    return redirect(url_for('auth.login'))
