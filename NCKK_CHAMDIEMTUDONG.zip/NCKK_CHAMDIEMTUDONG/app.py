from create_admin import create_default_admin
from flask import Flask, render_template # type: ignore
from models.init import db
from bkend.Auth import auth_bp
from bkend.student import student_bp
from bkend.teacher import teacher_bp
from bkend.admin import admin_bp

app = Flask(__name__)

app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///students.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
app.config['SECRET_KEY'] = 'secret-key'

db.init_app(app)

app.register_blueprint(auth_bp, url_prefix='/auth')
app.register_blueprint(student_bp, url_prefix='/student')
app.register_blueprint(teacher_bp, url_prefix='/teacher')
app.register_blueprint(admin_bp, url_prefix='/admin')

@app.route('/')
def page_home():
    return render_template('page_home.html')

if __name__ == '__main__':
    with app.app_context():
        db.create_all()
        create_default_admin()
    app.run(debug=True, host='0.0.0.0')
